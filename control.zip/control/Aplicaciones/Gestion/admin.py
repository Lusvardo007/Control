from django.contrib import admin
from Aplicaciones.Gestion.models import *
# Register your models here.

admin.site.register(Persona)
admin.site.register(Servicio)
admin.site.register(Servicioporcliente)