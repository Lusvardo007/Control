from django.db import models

# Create your models here.
class Persona(models.Model):
    dpi = models.PositiveSmallIntegerField(primary_key=True)
    nombre = models.CharField(max_length=30)
    nombreDos = models.CharField(max_length=30)
    apellido = models.CharField(max_length=30)
    apellidoDos = models.CharField(max_length=30)
    direccion = models.CharField(max_length=30)
    fachaNacimiento = models.DateField()
    telefono = models.CharField(max_length=8)
    email = models.CharField(max_length=30)
    sexos = [
        ('M', 'Masculino'),
        ('F', ' Femenino')
    ]
    sexo = models.CharField(max_length=1, choices=sexos, default='F')

    def nombr(self):
        txt = "{0}, {1},{2},{3}"
        return txt.format(self.nombre, self.nombreDos, self.apellido, self.apellidoDos)

class Servicio(models.Model):
    codigo = models.PositiveSmallIntegerField(primary_key=True)
    servicionombre = models.CharField(max_length=30)
    preciowhatshora =  models.FloatField()


class Servicioporcliente(models.Model):
    codigo = models.PositiveSmallIntegerField(primary_key=True)
    persona = models.ForeignKey(Persona, null=False, blank=False, on_delete=models.CASCADE)
    servicio = models.ForeignKey(Servicio, null=False, blank=False, on_delete=models.CASCADE)


